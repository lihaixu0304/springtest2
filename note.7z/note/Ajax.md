# Ajax

## 一，什么是ajax

### 概念：

ajax是异步的JavaScript和xml

### 作用：

1，与服务器进行数据交互：通过ajax给服务器发送请求，并获取服务器响应的数据。使用html+ajax来替换jsp页面。

2，实现异步交互：可以在不加载页面的情况下，与服务器交换数据并更新部分网页。

3，实现异步交互：在不重新加载整个页面的情况下，与服务器进行数据交互并更新部分网页。场景：搜索联想，登录校验

## 二，Ajax快速入门

### 1，原生ajax开发

1.1步骤：

（1）编写AjaxServlet ,并使用response输出字符串

```java
package com.lhx.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Author:李海旭
 * Date : 2023/6/21 14:26
 */
@WebServlet("/ajaxservlet")
public class AjaxServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1, 后台响应数据
        resp.getWriter().write("hello ajax!");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
```

（2）创建XMLHttpRequest对象，用于和服务器交换数据

```javascript
const xhttp = new XMLHttpRequest();
```

（3）向服务器发送请求

```javascript
xhttp.open("GET","http://localhost:8080/servlet_war/ajaxservlet");
xhttp.send();
```

（4）获取服务器响应数据 

```javascript
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        alert(xhttp.responseText);
    }
};
```

## 三，案例

验证用户名是否存在

register.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>欢迎注册</title>
    <link href="css/register.css" rel="stylesheet">
</head>
<body>

<div class="form-div">
    <div class="reg-content">
        <h1>欢迎注册</h1>
        <span>已有帐号？</span> <a href="login.html">登录</a>
    </div>
    <form id="reg-form" action="#" method="get">

        <table>

            <tr>
                <td>用户名</td>
                <td class="inputs">
                    <input name="username" type="text" id="username">
                    <br>
                    <span id="username_err" class="err_msg" style="display: none">用户名不太受欢迎</span>
                </td>

            </tr>

            <tr>
                <td>密码</td>
                <td class="inputs">
                    <input name="password" type="password" id="password">
                    <br>
                    <span id="password_err" class="err_msg" style="display: none">密码格式有误</span>
                </td>
            </tr>


            <tr>
                <td>验证码</td>
                <td class="inputs">
                    <input name="checkCode" type="text" id="checkCode">
                    <img src="imgs/a.jpg">
                    <a href="#" id="changeImg">看不清？</a>
                </td>
            </tr>

        </table>

        <div class="buttons">
            <input value="注 册" type="submit" id="reg_btn">
        </div>
        <br class="clear">
    </form>

</div>
<script>
    //给用户名输入框绑定失去焦点的事件
    document.getElementById("username").onblur = function (){
        //发送ajax请求
        //创建用户名
        var username = this.value;
        //创建核心对象
        var xhttp ;
        if (window.XMLHttpRequest){
            xhttp = new XMLHttpRequest();
        }else {
            xhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        //发送请求
        xhttp.open("GET","http://localhost:8080/servlet_war/selectServlet?username="+username);
        xhttp.send();
        //获取响应
        xhttp.onreadystatechange = function (){
            if (this.readyState == 4 && this.status == 200){
                //alert(this.responseText);
                if (this.responseText == "true"){
                    document.getElementById("username_err").style.display ='';
                }else {
                    document.getElementById("username_err").style.display = 'none';
                }
            }
        }
    };
</script>
</body>
</html>
```

```css
* {
    margin: 0;
    padding: 0;
    list-style-type: none;
}
.reg-content{
    padding: 30px;
    margin: 3px;
}
a, img {
    border: 0;
}

body {
    background-image: url("../imgs/reg_bg_min.jpg") ;
    text-align: center;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
}

td, th {
    padding: 0;
    height: 90px;

}
.inputs{
    vertical-align: top;
}

.clear {
    clear: both;
}

.clear:before, .clear:after {
    content: "";
    display: table;
}

.clear:after {
    clear: both;
}

.form-div {
    background-color: rgba(255, 255, 255, 0.27);
    border-radius: 10px;
    border: 1px solid #aaa;
    width: 424px;
    margin-top: 150px;
    margin-left:1050px;
    padding: 30px 0 20px 0px;
    font-size: 16px;
    box-shadow: inset 0px 0px 10px rgba(255, 255, 255, 0.5), 0px 0px 15px rgba(75, 75, 75, 0.3);
    text-align: left;
}

.form-div input[type="text"], .form-div input[type="password"], .form-div input[type="email"] {
    width: 268px;
    margin: 10px;
    line-height: 20px;
    font-size: 16px;
}

.form-div input[type="checkbox"] {
    margin: 20px 0 20px 10px;
}

.form-div input[type="button"], .form-div input[type="submit"] {
    margin: 10px 20px 0 0;
}

.form-div table {
    margin: 0 auto;
    text-align: right;
    color: rgba(64, 64, 64, 1.00);
}

.form-div table img {
    vertical-align: middle;
    margin: 0 0 5px 0;
}

.footer {
    color: rgba(64, 64, 64, 1.00);
    font-size: 12px;
    margin-top: 30px;
}

.form-div .buttons {
    float: right;
}

input[type="text"], input[type="password"], input[type="email"] {
    border-radius: 8px;
    box-shadow: inset 0 2px 5px #eee;
    padding: 10px;
    border: 1px solid #D4D4D4;
    color: #333333;
    margin-top: 5px;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
    border: 1px solid #50afeb;
    outline: none;
}

input[type="button"], input[type="submit"] {
    padding: 7px 15px;
    background-color: #3c6db0;
    text-align: center;
    border-radius: 5px;
    overflow: hidden;
    min-width: 80px;
    border: none;
    color: #FFF;
    box-shadow: 1px 1px 1px rgba(75, 75, 75, 0.3);
}

input[type="button"]:hover, input[type="submit"]:hover {
    background-color: #5a88c8;
}

input[type="button"]:active, input[type="submit"]:active {
    background-color: #5a88c8;
}
.err_msg{
    color: red;
    padding-right: 170px;
}
#password_err,#tel_err{
    padding-right: 195px;
}

#reg_btn{
    margin-right:50px; width: 285px; height: 45px; margin-top:20px;
}

#checkCode{
    width: 100px;
}

#changeImg{
    color: aqua;
}
```

## 四，Axios异步框架

## 1，什么是axios

Axios 是一个基于 *[promise](https://javascript.info/promise-basics)* 网络请求库，作用于[`node.js`](https://nodejs.org/) 和浏览器中。 它是 *[isomorphic](https://www.lullabot.com/articles/what-is-an-isomorphic-application)* 的(即同一套代码可以运行在浏览器和node.js中)。在服务端它使用原生 node.js `http` 模块, 而在客户端 (浏览端) 则使用 XMLHttpRequests。

## 2，axios快速入门

引入axios文件

使用 npm:

```bash
$ npm install axios
```

使用 bower:

```bash
$ bower install axios
```

使用 yarn:

```bash
$ yarn add axios
```

使用 jsDelivr CDN:

```html
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
```

使用 unpkg CDN:

```html
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
```

## 3，使用axios发送请求，获取响应结果

```javascript
axios({
method:"get",
url:"http://localhost:8080/com/lhx/servlet/AjaxServlet?username=zhangsan"
}).then(function(resp)){
	alert(resp,data);
});
```

```javascript
axios({
method:"post",
url:"http://localhost:8080/com/lhx/servlet/AjaxServlet",
data:"username=zhangsan"
}).then(function(resp)){
	alert(resp,data);
});
```

## 4,axios请求方式别名

```javascript
//get请求
axios.get("get").then(function(resp){
alert(resp,data);
});
```

```javascript
//post请求
axios.get("post","参数").then(function(resp){
alert(resp,data);
});
```



## 五，Json

## 1，什么是json

json（javaScript Object Notation）,java 对象表示法

作为数据载体 ，在网络中进行传输，易于书写和阅读

## 2，json的格式

```json
var 变量名 = {
"key1":"value1",
"key2":"value2",
"key3":"value3"
}；
```

```json
//示例1
var data = {
"name":"张三"，
"age":23
};


```

```json
//示例2
var data = {
"name":"zhangsan",
"addre":["楚雄","昆明","玉溪"]
};
```



## 3，json数据和java对象的转换

### 3.1json字符串转java对象（请求数据）

1，采用fastjson依赖，由阿里提供的高性能json库，目前java语言中最快的json库

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>fastjson</artifactId>
    <version>1.2.62</version>
</dependency>
```

```java
package com.lhx.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Author:李海旭
 * Date : 2023/6/26 15:42
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private String name;
    private String sex;
    private Integer age;
    
}
```

2,java对象转json

```java 
//格式
String jsonStr = JSON.toJSONString(obj);
```

```java
//示例
String s = JSON.toJSONString(user);
        System.out.println(s);
```

3,JSON字符串转java对象

```java 
//格式
User user = JSON.parseObject(jsonStr,User.class);
```

```java
//示例 
Object parse = JSON.parseObject("{\"age\":23,\"name\":\"李海旭\",\"sex\":\"男\"}", User.class);
        System.out.println(parse);
```



### 3.2Java对象转json字符串（响应数据）

## 4，案例

