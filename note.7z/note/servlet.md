```

```

# servlet

## 一、什么是Servlet

Servlet是动态web后端服务程序。

## 二、Servlet的工作原理

客户端发送请求给服务器--->服务器启动调用Servlet中的方法响应给服务器--->服务器将响应返回客户端

![image-20230719161304115](E:\javaproject\note\image\image-20230719161304115.png)

### 2.1、Servlet容器

servlet 创建ServletContext对象，封装应用程序的环境，一个servlet对应一个ServletContext。

### 2.2、Servlet接口方法

```java
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package javax.servlet;

import java.io.IOException;

public interface Servlet {
    void init(ServletConfig var1) throws ServletException;

    ServletConfig getServletConfig();

    void service(ServletRequest var1, ServletResponse var2) throws ServletException, IOException;

    String getServletInfo();

    void destroy();
}

```

### 2.3、Servlet生命周期

```java 
package com.lhx.object01;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

/**
 * Author:李海旭
 * Date : 2023/7/19 9:34
 */
@WebServlet()//使用注解进行注册
public class TestServlet implements Servlet {
       //只加载一次
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        System.out.println("初始化。。。");
    }
    //每次调用都加载
    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("service。。。");
    }
    //停止服务，销毁
    @Override
    public void destroy() {
        System.out.println("销毁。。。");
    }
}

```

servlet大致流程：服务启动初始化---进行服务---服务停止，销毁。

## 三、Servlet接口详解

### 3.1、ServletRequest

Servlet接收到的每一个Http请求，都会由ServletRequest对象，传递给Servlet的servic()方法。

```java
package javax.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

public interface ServletRequest {
    Object getAttribute(String var1);//获取属性值
    Enumeration<String> getAttributeNames();//获取属性名
    String getCharacterEncoding();//获取字符编码
    void setCharacterEncoding(String var1) throws UnsupportedEncodingException;//设置字符集编码格式
    String getParameter(String var1);//获取参数值
    Enumeration<String> getParameterNames();//获取参数名
    
    BufferedReader getReader() throws IOException;
    String getRemoteAddr();
    String getRemoteHost();
    void setAttribute(String var1, Object var2);
    void removeAttribute(String var1);
    Locale getLocale();
    Enumeration<Locale> getLocales();
    boolean isSecure();
    RequestDispatcher getRequestDispatcher(String var1);

    /** @deprecated */
    String getRealPath(String var1);
    int getRemotePort();
    String getLocalName();
    String getLocalAddr();
    int getLocalPort();
    ServletContext getServletContext();
    AsyncContext startAsync() throws IllegalStateException;
    AsyncContext startAsync(ServletRequest var1, ServletResponse var2) throws IllegalStateException;
    boolean isAsyncStarted();
    boolean isAsyncSupported();
    AsyncContext getAsyncContext();
    DispatcherType getDispatcherType();
}
```

### 3.2、ServletRespone

```java 
package javax.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public interface ServletResponse {
    String getCharacterEncoding();
    String getContentType();//获取响应内容
    ServletOutputStream getOutputStream() throws IOException;
    PrintWriter getWriter() throws IOException;
    void setCharacterEncoding(String var1);
    void setContentLength(int var1);
    void setContentLengthLong(long var1);
    void setContentType(String var1);//设置响应内容类型（text/html）
    void setBufferSize(int var1);
    int getBufferSize();
    void flushBuffer() throws IOException;
    void resetBuffer();
    boolean isCommitted();
    void reset();
    void setLocale(Locale var1);
    Locale getLocale();
}

```

### 3.3、常用接口

#### 1，HttpServlet

我们继承该抽象类，需要哪个方法就直接重写哪个方法，不需要重写该类中的所有方法。

HttpServlet 中的所有方法如下

```java
package javax.servlet.http;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.ResourceBundle;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public abstract class HttpServlet extends GenericServlet {
    private static final String METHOD_DELETE = "DELETE";
    private static final String METHOD_HEAD = "HEAD";
    private static final String METHOD_GET = "GET";
    private static final String METHOD_OPTIONS = "OPTIONS";
    private static final String METHOD_POST = "POST";
    private static final String METHOD_PUT = "PUT";
    private static final String METHOD_TRACE = "TRACE";
    private static final String HEADER_IFMODSINCE = "If-Modified-Since";
    private static final String HEADER_LASTMOD = "Last-Modified";
    private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
    private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");

    public HttpServlet() {
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       ...
    }

    protected long getLastModified(HttpServletRequest req) {
       ...
    }

    protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       ...
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       ...
    }

    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      ...
    }

    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ...
    }

    private Method[] getAllDeclaredMethods(Class<? extends HttpServlet> c) {
       ...
    }

    protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ...
    }

    protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ...
    }

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       ...
    }

    private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
       ...
    }

    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
      ...
}

```

![image-20230719113401546](E:\javaproject\note\image\image-20230719113401546.png)

#### 2、HttpServletRequest

```java
public interface HttpServletRequest extends ServletRequest {}
```

可以通过该对象分别获得HTTP请求的请求行，请求头和请求体。

![image-20230719153034254](E:\javaproject\note\image\image-20230719153034254.png)

request 获取请求行

```java
 	String getContextPath();
    String getQueryString();
    String getRequestURI()
    StringBuffer getRequestURL();
```

request 获取请求头

```java
 	long getDateHeader(String var1);
    String getHeader(String var1);
    Enumeration<String> getHeaders(String var1);
    Enumeration<String> getHeaderNames();
    int getIntHeader(String var1);
```

request 获取请求体

```java
String getParameter(String name)
String[] getParameterValues(String name)
Enumeration getParameterNames()
Map<String,String[]> getParameterMap()
```

request提交解决乱码的解决

post提交：

```java
request.setCharacterEncoding("UTF-8");
```

get提交：

```java
parameter = newString(parameter.getbytes("iso8859-1"),"utf-8");
```



#### 3、HttpServletResponse

```java
public interface HttpServletResponse extends ServletResponse {}
```

![](E:\javaproject\note\image\image-20230719145929663.png)

response 获取响应头

```java 
	String getHeader(String var1);

    Collection<String> getHeaders(String var1);

    Collection<String> getHeaderNames();
```

response响应设置

```java
void addCookie(Cookie var1);//给这个响应添加一个cookie
void addHeader(String var1, String var2);//给这个请求添加一个响应头
void sendRedirect(String var1) throws IOException;//发送一条响应码，讲浏览器跳转到指定的位置
void setStatus(int var1);//设置响应行的状态码
```

response 响应编码问题

1，中文响应编码：

```java
resp.setCharacterEncoding("UTF-8");
```

2，即使是设置了响应编码，但是在浏览器中依然显示乱码的解决办法

```java
//调用该方法，通知浏览器响应类型和响应字符类型
 resp.setContentType("text/html;charset=utf-8");
```

#### 4、http响应状态码

```xml
100	Continue	服务器只收到了请求的一部分，但只要它没有被拒绝，客户端就应该继续请求
101	Switching Protocols	服务器切换协议。
200	OK	请求是可以的
201	Created	请求完成，并创建新资源
202	Accepted	已接受该请求以进行处理，但处理尚未完成。
203	Non-authoritative Information	 
204	No Content	 
205	Reset Content	 
206	Partial Content	 
300	Multiple Choices	链接列表。用户可以选择一个链接并转到该位置。最多五个地址
301	Moved Permanently	请求的页面已移至新的url
302	Found	请求的页面已临时移动到新的url
303	See Other	可以在不同的url下找到请求的页面
304	Not Modified	 
305	Use Proxy	 
306	Unused	此代码在以前的版本中使用。它不再使用，但代码是保留的
307	Temporary Redirect	请求的页面已临时移动到新的URL。
400	Bad Request	服务器不理解该请求
401	Unauthorized	请求的页面需要用户名和密码
402	Payment Required	您还不能使用此代码
403	Forbidden	禁止访问请求的页面
404	Not Found	服务器找不到请求的页面。
	 
500	内部服务器错误	请求未完成。服务器遇到意外情况。
```

## 四、Filter过滤器

### 4.1、filter继承体系

```java
package com.lhx.filter;

import javax.servlet.*;
import java.io.IOException;

/**
 * Author:李海旭
 * Date : 2023/7/19 17:00
 */
public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}

```

### 4.2、filter开发步骤

1. java类实现Filter接口

2. 重写doFilter方法

3. ```java
   @Override
       public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
   
       }
   ```

   

4. 过滤处理

5. 过滤处理后，使用FilterChain放行

6. 设置需要xml配置或注解配置

```xml
<web-app>
  <display-name>Archetype Created Web Application</display-name>
<filter>
  <filter-name>loginfilter</filter-name>
  <filter-class>com.lhx.filter.LoginFilter</filter-class>
</filter>
  <filter-mapping>
    <filter-name>loginfilter</filter-name>
    <url-pattern>/*</url-pattern>
  </filter-mapping>

</web-app>
```

### 4.3、filter优先级

在xml配置中，过滤器的优先级是根据filter-mapping注册顺序，从上往下执行

在注解中，过滤器是按照类名的字典顺序执行的。如果不同包的Filter类，先按照包名的字典顺序寻找Filter，分包后再按照类名字典顺序执行

注意：在web.xml配置的优先级高于注解配置的优先级

### 4.4、filter自动登录

页面：

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登录页面</title>
</head>
<body>
<form action="/firstfilter/login" method="post">
    账号:<input type="text" name="username"><br>
    密码:<input type="password" name="password"><br>
    自动登录 <input type="checkbox" name="autoLogin" value="autoLogin"><br>
    <button type="submit">登录</button>
</form>
</body>
</html>

```

LoginServlet.java

```java 
package com.mylifes1110.java.demo.servlet;

import com.mylifes1110.java.demo.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 登录处理
 */
@WebServlet(name = "LoginServlet", value = "/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 1.获取请求参数账号和密码
         * 2.对帐号和密码进行校验（成功，则判断是否获取的到自动登录参数，是的话讲账号、密码存储在Cookie中）
         * 3.封装成对象存储在Session中
         * 4.转发至展示页面
         */
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if ("ziph".equals(username) && "123456".equals(password)) {
            String autoLogin = request.getParameter("autoLogin");
            if ("autoLogin".equals(autoLogin)) {
                Cookie cookie = new Cookie("autoLogin", username + "-" + password);
                cookie.setMaxAge(60 * 60 * 24 * 7);
                response.addCookie(cookie);
            }
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            request.getSession().setAttribute("user", user);
            request.getRequestDispatcher("/show").forward(request, response);
        } else {
            /**
             * 登录失败转发至登录页面
             */
            request.getRequestDispatcher("/login.html").forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

```

AutoLoginFilter.java

```java
package com.mylifes1110.java.demo.filter;

import com.mylifes1110.java.demo.entity.User;
import com.mylifes1110.java.demo.utils.CookieUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * 实现自动登录的过滤器
 */
@WebFilter(filterName = "AutoLoginFilter", value = "/*")
public class AutoLoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest request = (HttpServletRequest) req;
        //获取请求路径
        String requestURI = request.getRequestURI();
        //判断请求路径是否与登录资源相关
        if (requestURI.contains("login")) {
            //请求是与登录相关资源
            chain.doFilter(request, resp);
        } else {
            /**
             * 请求的不是与登录的相关资源
             */
            User user = (User) request.getSession().getAttribute("user");
            /**
             * 判断登录状态
             */
            if (user == null) {
                Cookie cookie = CookieUtils.getCookie(request.getCookies(), "autoLogin");
                //cookie为空（被清理的缓存）
                if (cookie == null) {
                    //cookie被清理了，自动登录失败，请求转发至登录页面
                    request.getRequestDispatcher("/login.html").forward(request, resp);
                } else {
                    //有cookie进行自动登录操作
                    //获取账号信息，拼接好的字符串ziph-123456b，并进行拆分
                    String cookieValue = cookie.getValue();
                    String[] split = cookieValue.split("-");
                    String username = split[0];
                    String password = split[1];
                    if ("ziph".equals(username) && "123456".equals(password)) {
                        //自动登录成功，修改登陆状态，直接放行
                        user = new User();
                        user.setUsername(username);
                        user.setPassword(password);
                        request.getSession().setAttribute("user", user);
                        chain.doFilter(request, resp);
                    } else {
                        //自动登陆失败（修改了密码），转发至登录页面
                        request.getRequestDispatcher("/login.html").forward(request, resp);
                    }
                }
            } else {
                //在登录状态直接放行
                chain.doFilter(request, resp);
            }
        }
    }

    public void init(FilterConfig config) throws ServletException {

    }

}

```

CookieUtil.java

```java
package com.mylifes1110.java.demo.utils;

import javax.servlet.http.Cookie;

public class CookieUtils {
    public static Cookie getCookie(Cookie[] cookies, String cookieName) {
        if (cookies != null && cookies.length != 0) {
            for (Cookie cookie : cookies) {
                if (cookieName.equals(cookie.getName())) {
                    return cookie;
                }
            }
        }
        return null;
    }
}

```

登录结果展示

ShowServlet.java

```java
package com.mylifes1110.java.demo.servlet;

import com.mylifes1110.java.demo.entity.User;
import com.sun.org.apache.xpath.internal.operations.String;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.Buffer;

/**
 * 展示登录结果
 */
@WebServlet(name = "ShowServlet", value = "/show")
public class ShowServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        User user = (User) request.getSession().getAttribute("user");
        StringBuffer buffer = new StringBuffer();
        if (user == null) {
            buffer.append("对不起，您还没有登录！<br><a href='/firstfilter/login.html'>请登录</a>");
        } else {
            buffer.append(user.getUsername() + " 主人，您回来啦！");
        }
        response.getWriter().println(buffer.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

```

## 五、会话技术

### 5.1会话技术分类

Cookie:客户端状态管理，状态保存在客户端。

Session:服务端状态管理，状态保存在服务端。

### 5.2、生命周期

cookie的生命周期，设置Cookie生命周期时间核心代码：**cookie.setMaxAge();** （设置生命周期时间）

## 六、文件上传和下载

### 6.1、文件上传

(1)核心思想：将电脑中的本地文件根据网络协议并通过IO流的读写传递到另一台电脑（服务器）中储存！

(2)文件上传的要素：

```
表单提交方式必须是post（method=post）
原因get提交方式只能提交小文件，而给文件上传做了很大的限制；post可以提交大文件

表单中需要文件上传项（<input type=“file”>）
既然要实现文件上传，那么就需要文件上传按钮和上传文件框

表单设置请求体格式（enctype=multipart/form-data）

设置表单的MIME编码。默认情况编码格式是application/x-www-form-urlencoded，不能用于文件上传。只有设置了multipart/form-data，才能完整的传递文件数据
```

```javascript
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>文件上传</title>
</head>
<body>
<form action="${pageContext.request.contextPath}/upload" method="post" enctype="multipart/form-data">
    文件描述：<input type="text" name="description"><br>
    <input type="file" name="file"><br>
    <br>
    <button type="submit">上传</button>
</form>
</body>
</html>

```

(3)核心文件

```java
ServletFileUpload：核心解析类

方法	描述
parseRequest(HttpServletRequest request)	解析请求，并获取相关文件项
setHeaderEncoding(String encoding)	解决中文文件名乱码
FileItem：文件项

方法	描述
boolean isFormField()	返回为true为普通字段。返回为false为文件
String getFieldName()	获取表单字段
String getString(String encoding)	根据指定编码格式获取字段值
String getName()	获取上传文件名称
InputStream getInputStream()	获取上传文件对应的输入流
```



### 6.2、文件下载

(1)核心思想：将服务器中的文件根据网络协议并通过IO流读取传递到另外一台电脑中并储存！

（2）文件下载格式：

- 超链接
  - 如果浏览器支持这个格式的文件.可以在浏览器中打开.如果浏览器不支持这个格式的文 件才会提示下载
- 手动编写代码的方式下载

（3）文件下载要素

```
设置响应对象的媒体类型
设置下载窗口
设置下载窗口是通过响应对象对响应头的操作（“Content-Disposition”）
IO流读写文件
```



## 七、Servlet实战

登录 案例

需求：用户输入用户名和密码，提交后台，后台做出响应，返回登录 成功或者失败 信息。

登录页面

```html
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>login</title>
</head>
<body>
<h1>欢迎登录！</h1>
<div style="align-content: center;font-family: 新宋体;font-size: 20px">
  <form method="get" >
    <label>
      username:
      <input type="text">
    </label>
    </br>
    <label>
      password:
      <input type="password">
    </label>
    </br>
    <input type="submit" value="login" style="align-content: center;font-size: 23px;font-family: 新宋体;">
  </form>
</div>
</body>
</html>
```

```java
package com.lhx.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Author:李海旭
 * Date : 2023/7/19 16:37
 */
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符
          req.setCharacterEncoding("utf-8");
          resp.setContentType("text/html;charset=utf-8");
          //获取请求方式
        String method = req.getMethod();
        //获取url
        String requestURI = req.getRequestURI();
        //获取请求名称
        String contextPath = req.getContextPath();
        //获取查询字符串
        String queryString = req.getQueryString();

        //响应
        resp.getWriter().write(method);
        resp.getWriter().write(requestURI);
        resp.getWriter().write(contextPath);
        resp.getWriter().write(queryString);
    }
}

```

Ajax

## 八，什么是ajax

### 概念

ajax是异步的JavaScript和xml

### 作用

1，与服务器进行数据交互：通过ajax给服务器发送请求，并获取服务器响应的数据。使用html+ajax来替换jsp页面。

2，实现异步交互：可以在不加载页面的情况下，与服务器交换数据并更新部分网页。

3，实现异步交互：在不重新加载整个页面的情况下，与服务器进行数据交互并更新部分网页。场景：搜索联想，登录校验

## 九，Ajax快速入门

### 1，原生ajax开发

1.1步骤：

（1）编写AjaxServlet ,并使用response输出字符串

```java
package com.lhx.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Author:李海旭
 * Date : 2023/6/21 14:26
 */
@WebServlet("/ajaxservlet")
public class AjaxServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1, 后台响应数据
        resp.getWriter().write("hello ajax!");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
```

（2）创建XMLHttpRequest对象，用于和服务器交换数据

```javascript
const xhttp = new XMLHttpRequest();
```

（3）向服务器发送请求

```javascript
xhttp.open("GET","http://localhost:8080/servlet_war/ajaxservlet");
xhttp.send();
```

（4）获取服务器响应数据 

```javascript
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        alert(xhttp.responseText);
    }
};
```

## 十，案例

验证用户名是否存在

register.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>欢迎注册</title>
    <link href="css/register.css" rel="stylesheet">
</head>
<body>

<div class="form-div">
    <div class="reg-content">
        <h1>欢迎注册</h1>
        <span>已有帐号？</span> <a href="login.html">登录</a>
    </div>
    <form id="reg-form" action="#" method="get">

        <table>

            <tr>
                <td>用户名</td>
                <td class="inputs">
                    <input name="username" type="text" id="username">
                    <br>
                    <span id="username_err" class="err_msg" style="display: none">用户名不太受欢迎</span>
                </td>

            </tr>

            <tr>
                <td>密码</td>
                <td class="inputs">
                    <input name="password" type="password" id="password">
                    <br>
                    <span id="password_err" class="err_msg" style="display: none">密码格式有误</span>
                </td>
            </tr>


            <tr>
                <td>验证码</td>
                <td class="inputs">
                    <input name="checkCode" type="text" id="checkCode">
                    <img src="imgs/a.jpg">
                    <a href="#" id="changeImg">看不清？</a>
                </td>
            </tr>

        </table>

        <div class="buttons">
            <input value="注 册" type="submit" id="reg_btn">
        </div>
        <br class="clear">
    </form>

</div>
<script>
    //给用户名输入框绑定失去焦点的事件
    document.getElementById("username").onblur = function (){
        //发送ajax请求
        //创建用户名
        var username = this.value;
        //创建核心对象
        var xhttp ;
        if (window.XMLHttpRequest){
            xhttp = new XMLHttpRequest();
        }else {
            xhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        //发送请求
        xhttp.open("GET","http://localhost:8080/servlet_war/selectServlet?username="+username);
        xhttp.send();
        //获取响应
        xhttp.onreadystatechange = function (){
            if (this.readyState == 4 && this.status == 200){
                //alert(this.responseText);
                if (this.responseText == "true"){
                    document.getElementById("username_err").style.display ='';
                }else {
                    document.getElementById("username_err").style.display = 'none';
                }
            }
        }
    };
</script>
</body>
</html>
```

```css
* {
    margin: 0;
    padding: 0;
    list-style-type: none;
}
.reg-content{
    padding: 30px;
    margin: 3px;
}
a, img {
    border: 0;
}

body {
    background-image: url("../imgs/reg_bg_min.jpg") ;
    text-align: center;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
}

td, th {
    padding: 0;
    height: 90px;

}
.inputs{
    vertical-align: top;
}

.clear {
    clear: both;
}

.clear:before, .clear:after {
    content: "";
    display: table;
}

.clear:after {
    clear: both;
}

.form-div {
    background-color: rgba(255, 255, 255, 0.27);
    border-radius: 10px;
    border: 1px solid #aaa;
    width: 424px;
    margin-top: 150px;
    margin-left:1050px;
    padding: 30px 0 20px 0px;
    font-size: 16px;
    box-shadow: inset 0px 0px 10px rgba(255, 255, 255, 0.5), 0px 0px 15px rgba(75, 75, 75, 0.3);
    text-align: left;
}

.form-div input[type="text"], .form-div input[type="password"], .form-div input[type="email"] {
    width: 268px;
    margin: 10px;
    line-height: 20px;
    font-size: 16px;
}

.form-div input[type="checkbox"] {
    margin: 20px 0 20px 10px;
}

.form-div input[type="button"], .form-div input[type="submit"] {
    margin: 10px 20px 0 0;
}

.form-div table {
    margin: 0 auto;
    text-align: right;
    color: rgba(64, 64, 64, 1.00);
}

.form-div table img {
    vertical-align: middle;
    margin: 0 0 5px 0;
}

.footer {
    color: rgba(64, 64, 64, 1.00);
    font-size: 12px;
    margin-top: 30px;
}

.form-div .buttons {
    float: right;
}

input[type="text"], input[type="password"], input[type="email"] {
    border-radius: 8px;
    box-shadow: inset 0 2px 5px #eee;
    padding: 10px;
    border: 1px solid #D4D4D4;
    color: #333333;
    margin-top: 5px;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
    border: 1px solid #50afeb;
    outline: none;
}

input[type="button"], input[type="submit"] {
    padding: 7px 15px;
    background-color: #3c6db0;
    text-align: center;
    border-radius: 5px;
    overflow: hidden;
    min-width: 80px;
    border: none;
    color: #FFF;
    box-shadow: 1px 1px 1px rgba(75, 75, 75, 0.3);
}

input[type="button"]:hover, input[type="submit"]:hover {
    background-color: #5a88c8;
}

input[type="button"]:active, input[type="submit"]:active {
    background-color: #5a88c8;
}
.err_msg{
    color: red;
    padding-right: 170px;
}
#password_err,#tel_err{
    padding-right: 195px;
}

#reg_btn{
    margin-right:50px; width: 285px; height: 45px; margin-top:20px;
}

#checkCode{
    width: 100px;
}

#changeImg{
    color: aqua;
}
```

## 十一，Axios异步框架

## 1，什么是axios

Axios 是一个基于 *[promise](https://javascript.info/promise-basics)* 网络请求库，作用于[`node.js`](https://nodejs.org/) 和浏览器中。 它是 *[isomorphic](https://www.lullabot.com/articles/what-is-an-isomorphic-application)* 的(即同一套代码可以运行在浏览器和node.js中)。在服务端它使用原生 node.js `http` 模块, 而在客户端 (浏览端) 则使用 XMLHttpRequests。

## 2，axios快速入门

引入axios文件

使用 npm:

```bash
$ npm install axios
```

使用 bower:

```bash
$ bower install axios
```

使用 yarn:

```bash
$ yarn add axios
```

使用 jsDelivr CDN:

```html
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
```

使用 unpkg CDN:

```html
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
```

## 3，使用axios发送请求，获取响应结果

```javascript
axios({
method:"get",
url:"http://localhost:8080/com/lhx/servlet/AjaxServlet?username=zhangsan"
}).then(function(resp)){
	alert(resp,data);
});
```

```javascript
axios({
method:"post",
url:"http://localhost:8080/com/lhx/servlet/AjaxServlet",
data:"username=zhangsan"
}).then(function(resp)){
	alert(resp,data);
});
```

## 4,axios请求方式别名

```javascript
//get请求
axios.get("get").then(function(resp){
alert(resp,data);
});
```

```javascript
//post请求
axios.get("post","参数").then(function(resp){
alert(resp,data);
});
```



## 十二、Json

## 1，什么是json

json（javaScript Object Notation）,java 对象表示法

作为数据载体 ，在网络中进行传输，易于书写和阅读

## 2，json的格式

```json
var 变量名 = {
"key1":"value1",
"key2":"value2",
"key3":"value3"
}；
```

```json
//示例1
var data = {
"name":"张三"，
"age":23
};


```

```json
//示例2
var data = {
"name":"zhangsan",
"addre":["楚雄","昆明","玉溪"]
};
```



## 3，json数据和java对象的转换

### 3.1json字符串转java对象（请求数据）

1，采用fastjson依赖，由阿里提供的高性能json库，目前java语言中最快的json库

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>fastjson</artifactId>
    <version>1.2.62</version>
</dependency>
```

```java
package com.lhx.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Author:李海旭
 * Date : 2023/6/26 15:42
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private String name;
    private String sex;
    private Integer age;
    
}
```

2,java对象转json

```java 
//格式
String jsonStr = JSON.toJSONString(obj);
```

```java
//示例
String s = JSON.toJSONString(user);
        System.out.println(s);
```

3,JSON字符串转java对象

```java 
//格式
User user = JSON.parseObject(jsonStr,User.class);
```

```java
//示例 
Object parse = JSON.parseObject("{\"age\":23,\"name\":\"李海旭\",\"sex\":\"男\"}", User.class);
        System.out.println(parse);
```

# MyBatis

### 13.1、什么是MyBatis

MyBatis 是一款优秀的持久层框架，它支持自定义 SQL、存储过程以及高级映射。MyBatis 免除了几乎所有的 JDBC 代码以及设置参数和获取结果集的工作。MyBatis 可以通过简单的 XML 或注解来配置和映射原始类型、接口和 Java POJO（Plain Old Java Objects，普通老式 Java 对象）为数据库中的记录。

### 13.2、MyBatis入门

#### 1、介绍

每个基于 MyBatis 的应用都是以一个 SqlSessionFactory 的实例为核心的。SqlSessionFactory 的实例可以通过 SqlSessionFactoryBuilder 获得。而 SqlSessionFactoryBuilder 则可以从 XML 配置文件或一个预先配置的 Configuration 实例来构建出 SqlSessionFactory 实例。

#### 2、使用xml构建核心

XML 配置文件中包含了对 MyBatis 系统的核心设置，包括获取数据库连接实例的数据源（DataSource）以及决定事务作用域和控制方式的事务管理器（TransactionManager）。

示例：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
  PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
  "https://mybatis.org/dtd/mybatis-3-config.dtd"><!--*.dtd文档类型定义（自定义文档类型约束，下面的内容都得按照我的约束来进行编写）-->
<configuration>
  <environments default="development">
      <!--环境信息：有test(测试环境)，product（生产环境）,development（开发环境）-->
    <environment id="development">
      <transactionManager type="JDBC"/>
        <!--数据源配置信息-->
      <dataSource type="POOLED">
          <!--数据源-->
        <property name="driver" value="${driver}"/>
          <!--url信息-->
        <property name="url" value="${url}"/>
          <!--数据库用户名-->
        <property name="username" value="${username}"/>
          <!--数据库登录密码-->
        <property name="password" value="${password}"/>
      </dataSource>
    </environment>
  </environments>
    <!--mapper映射扫描信息-->
  <mappers>
    <mapper resource="org/mybatis/example/BlogMapper.xml"/>
  </mappers>
</configuration>
```

### 13.3 sql映射

#### 1使xml配置文件编写简单sql语句

MyBatis 的真正强大在于它的语句映射，这是它的魔力所在。由于它的异常强大，映射器的 XML 文件就显得相对简单。如果拿它跟具有相同功能的 JDBC 代码进行对比，你会立即发现还是xml 省事

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.lhx.mapper.UserMapper">
    <!--查询-->
    <select id="selectAll" resultType="User">
        select  * from admin where username = #{}  and password = #{}
    </select>
    <!--插入-->
    <insert id="insertAll" >
        insert into user(id,usernaem,password) values (#{id},#{username},#{pssword})
    </insert>
    <!--更新-->
    <update id="upsateAll" databaseId="1">
        update admin set username = "#{username}" where id = #{id}
    </update>
    <!--删除-->
    <delete id="deleteAll" databaseId="#{id}">
        delete from admin where id = #{id}
    </delete>
</mapper>
```

#### 2、参数设置问题：

使用占位符,#{ }和${ }的区别

```
#{ }：预编译sql，防止sql注入攻击，安全

${ }:不进行预编译，直接替换字符串，不安全
```

#### 3、xml文件配置下的所有标签

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <!--环境配置-->
    <environments default="development">
        <!--环境变量-->
        <environment id="development">
            <!--事务管理器-->
            <transactionManager type="JDBC"/>
            <!--数据源-->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.cj.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://localhost:3306/user"/>
                <property name="username" value="root"/>
                <property name="password" value="root"/>
            </dataSource>
        </environment>
    </environments>
    
    <!--数据库厂商标识-->
    <databaseIdProvider type=""></databaseIdProvider>
    <!--对象工厂-->
    <objectFactory type=""></objectFactory>
    <!--类型处理器-->
    <typeHandlers></typeHandlers>
    <!--类型别名-->
    <typeAliases></typeAliases>
    <!--设置-->
    <settings>
        <setting name="" value=""/>
    </settings>
    <!--属性-->
    <properties></properties>
    <!--插件-->
    <plugins>
        <plugin interceptor=""></plugin>
    </plugins>
    <!--mapper映射器-->
    <mappers>
        <mapper class="com.lhx.mapper.UserMapper"></mapper>
    </mappers>
</configuration>
```

#### 4、标签详解

##### （1）properties

说明：这些属性可以在外部进行配置，并可以进行动态替换。你既可以在典型的 Java 属性文件中配置这些属性，也可以在 properties 元素的子元素中设置。

属性中的参数可以定义好或者替换

方式1:直接定义（修改麻烦）

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <!--环境配置-->
    <environments default="development">
        <!--环境变量-->
        <environment id="development">
            <!--事务管理器-->
            <transactionManager type="JDBC"/>
            <!--数据源-->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.cj.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://localhost:3306/user"/>
                <property name="username" value="root"/>
                <property name="password" value="root"/>
            </dataSource>
        </environment>
    </environments>
    <!--mapper映射器-->
    <mappers>
        <mapper class="com.lhx.mapper.UserMapper"></mapper>
    </mappers>
</configuration>
```

方式2：读取外部配置文件（灵活，方便修改）

首先定义外部文件，这里我们以德鲁伊数据数据为例子

druid.properties

```properties
jdbc.driver=com.mysql.cj.jdbc.Driver
jdbc.url=jdbc:mysql://127.0.0.1:3306/user?useSSL=true&useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&failOverReadOnly=false&useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC
jdbc.username=root
jdbc.password=123456
```

定义好外部文件后，在mybatis-config.xml中进行配置

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <!--引入外部文件!!!!!!!!!!!!!!(必看的地方)-->
    <properties resource="druid.properties"></properties>
    <!--环境配置-->
    <environments default="development">
        <!--环境变量-->
        <environment id="development">
            <!--事务管理器-->
            <transactionManager type="JDBC"/>
            <!--数据源-->
            <dataSource type="POOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>
    <!--mapper映射器-->
    <mappers>
        <mapper class="com.lhx.mapper.UserMapper"></mapper>
    </mappers>
</configuration>
```

##### （2）settings

这是 MyBatis 中极为重要的调整设置，它们会改变 MyBatis 的运行时行为。

![image-20230721164655868](E:\javaproject\note\image\image-20230721164655868.png)

![image-20230721164751009](E:\javaproject\note\image\image-20230721164751009.png)

![image-20230721164816350](E:\javaproject\note\image\image-20230721164816350.png)

```xml
<settings>
  <setting name="cacheEnabled" value="true"/>
  <setting name="lazyLoadingEnabled" value="true"/>
  <setting name="aggressiveLazyLoading" value="true"/>
  <setting name="multipleResultSetsEnabled" value="true"/>
  <setting name="useColumnLabel" value="true"/>
  <setting name="useGeneratedKeys" value="false"/>
  <setting name="autoMappingBehavior" value="PARTIAL"/>
  <setting name="autoMappingUnknownColumnBehavior" value="WARNING"/>
  <setting name="defaultExecutorType" value="SIMPLE"/>
  <setting name="defaultStatementTimeout" value="25"/>
  <setting name="defaultFetchSize" value="100"/>
  <setting name="safeRowBoundsEnabled" value="false"/>
  <setting name="safeResultHandlerEnabled" value="true"/>
  <setting name="mapUnderscoreToCamelCase" value="false"/>
  <setting name="localCacheScope" value="SESSION"/>
  <setting name="jdbcTypeForNull" value="OTHER"/>
  <setting name="lazyLoadTriggerMethods" value="equals,clone,hashCode,toString"/>
  <setting name="defaultScriptingLanguage" value="org.apache.ibatis.scripting.xmltags.XMLLanguageDriver"/>
  <setting name="defaultEnumTypeHandler" value="org.apache.ibatis.type.EnumTypeHandler"/>
  <setting name="callSettersOnNulls" value="false"/>
  <setting name="returnInstanceForEmptyRow" value="false"/>
  <setting name="logPrefix" value="exampleLogPreFix_"/>
  <setting name="logImpl" value="SLF4J | LOG4J | LOG4J2 | JDK_LOGGING | COMMONS_LOGGING | STDOUT_LOGGING | NO_LOGGING"/>
  <setting name="proxyFactory" value="CGLIB | JAVASSIST"/>
  <setting name="vfsImpl" value="org.mybatis.example.YourselfVfsImpl"/>
  <setting name="useActualParamName" value="true"/>
  <setting name="configurationFactory" value="org.mybatis.example.ConfigurationFactory"/>
</settings>
```

##### （3）typeAliases

类型别名可为 Java 类型设置一个缩写名字。 它仅用于 XML 配置，意在降低冗余的全限定类名书写。简化包名的书写

![image-20230721170232213](E:\javaproject\note\image\image-20230721170232213.png)

```xml
<typeAliases>
        <typeAlias type="com.lhx.entitry" alias="user"></typeAlias>
</typeAliases>
```

包别名

![image-20230721170504396](E:\javaproject\note\image\image-20230721170504396.png)

```xml
<typeAliases>
		 <!--包别名-->
        <package name="com.lhx.mapper"/>
</typeAliases>
```

##### （4）mappers

针对sql语句的映射

```xml
<!-- 使用相对于类路径的资源引用 -->
<mappers>
  <mapper resource="org/mybatis/builder/AuthorMapper.xml"/>
  <mapper resource="org/mybatis/builder/BlogMapper.xml"/>
  <mapper resource="org/mybatis/builder/PostMapper.xml"/>
</mappers>
<!-- 使用完全限定资源定位符（URL） -->
<mappers>
  <mapper url="file:///var/mappers/AuthorMapper.xml"/>
  <mapper url="file:///var/mappers/BlogMapper.xml"/>
  <mapper url="file:///var/mappers/PostMapper.xml"/>
</mappers>
<!-- 使用映射器接口实现类的完全限定类名 -->
<mappers>
  <mapper class="org.mybatis.builder.AuthorMapper"/>
  <mapper class="org.mybatis.builder.BlogMapper"/>
  <mapper class="org.mybatis.builder.PostMapper"/>
</mappers>
<!-- 将包内的映射器接口全部注册为映射器 -->
<mappers>
  <package name="org.mybatis.builder"/>
</mappers>
```

### 13.4xml映射器

MyBatis 的真正强大在于它的语句映射，这是它的魔力所在。由于它的异常强大，映射器的 XML 文件就显得相对简单。如果拿它跟具有相同功能的 JDBC 代码进行对比，你会立即发现省掉了将近 95% 的代码。MyBatis 致力于减少使用成本，让用户能更专注于 SQL 代码。

#### （1）select

简单查询

```xml
<select id="selectPerson",parameterType="int",resultType="hashmap">
	select * from person where id = #{id}
</select>
<!--
参数说明：
id：唯一标识符
parameterType:参数类型
resultType:结果类型
-->
```

完整参数解释

![image-20230725145200800](E:\javaproject\note\image\image-20230725145200800.png)

#### （2）insert

```xml
<insert id="insertAuthor">
  insert into Author (id,username,password,email,bio)
  values (#{id},#{username},#{password},#{email},#{bio})
</insert>
```



#### （3）update

```xml
<update id="updateAuthor">
  update Author set
    username = #{username},
    password = #{password},
    email = #{email},
    bio = #{bio}
  where id = #{id}
</update>
```



#### （4）delete

```xml
<delete id="deleteAuthor">
  delete from Author where id = #{id}
</delete>
```



#### （5）截图工具

![image-20230725153118922](E:\javaproject\note\image\image-20230725153118922.png)

#  Spring

以spring6.0.4版本进行学习，在创建项目时，jdk必须选择jdk17版本

## 14.1、Spring核心技术

### 1、IOC核心容器

ioc:控制反转,用来管理我们的Bean,通过配置手段会告诉ioc要管理的资源

开始，在resources目录下创建名称为application.xml的配置文件

![image-20230725153308460](E:\javaproject\note\image\image-20230725153308460.png)

**案例：对象的创建和提供交给bean**

（1）创建对象Student和配置Bean

```java
package com.springtest.day01;
/**
 * Author:李海旭
 * Date : 2023/7/25 15:46
 */
//学生类对象
public class Student {}
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">
    <!--配置被管理的对象-->
    <bean name="student" class="com.springtest.day01.Student"></bean>
</beans>
```

（2）创建容器扫描Application

```java 
package com.springtest.day01;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Author:李海旭
 * Date : 2023/7/25 15:08
 */
public class Test {
    public static void main(String[] args) {
        //容器配置
        ApplicationContext context = new ClassPathXmlApplicationContext("application.xml");
        //从容器中拿student对象,不需要自己new
        Student student = context.getBean(Student.class);
        System.out.println(student);
    }
}
```

（3）执行

![image-20230725155812175](E:\javaproject\note\image\image-20230725155812175.png)

（4）成功打印了对象所在位置，说明，利用容器提供对象成功！

### 2、Bean的注册与配置

详细了解如何向Spring注册Bea和Bean相关的配置

